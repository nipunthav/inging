Inging Rubcase v1.0

How to run:
1. Extract this ZIP.
2. Open index.html in your browser.
3. Fill in fields on the left.
4. Generated LINE message appears on the right.
5. Click Copy, then paste into LINE.

Main template output:

รับใหม่ อ.[teacher name]
Ward: [ward name]
ผู้ป่วย: [patient name] [Male/Female] [age]y
HN: [hn]
U/D: [ud]
Problem List:
[problem list]
Plan:
- [plan]

Features:
- Male/Female output
- Grey low-brightness interface
- Left input / right output layout
- Mobile-friendly layout
- Auto-save last entered data
- Teacher favorites
- One-click copy
- Auto-bullets for Plan
- Multiple templates: รับใหม่, Progress, Consult, Discharge
- Export generated message as .txt
